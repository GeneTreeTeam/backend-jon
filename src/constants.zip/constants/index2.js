import * as auth from './auth2';
import * as firebase from './firebase2';

export {
  auth,
  firebase,
};