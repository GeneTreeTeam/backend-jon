//import {doSignInWithEmailAndPassword} from "./auth";
//import {tryMe, signUp, addPerson, signIn, addFather, addMother,displayFam,editMe} from "./functions";
//import * as oof from "./functions";
import {auth,firebase,store} from "./firebase";
import {read, write,logIn, signUp,whoAmI} from "./people";
import Person from "./people";
//signUp("Nawni","nani3@gmail.com","fml1235!");
//signUp("Jonathan","blah@gmail.com","oof12345");
//doSignInWithEmailAndPassword("whoopee@gmail.com","oof12345") .then(function(user) {
  //  console.log(user);
   // addPerson(user,"Ngoc","Dang","female");
//});

//signIn('myvu@gmail.com',"oof12345");

//
// var userId = "K469jg05DnZHqn8yzp1Ucghc12n2";
// editMe(userId,0,'Firstname','Joanne');
// var blah  = signIn("whoopee@gmail.com","oof12345");
// var oldLog = console.log;
// console.log(blah);
// console.log("hellO"  + blah);
// addPerson(userId,"Ngoc","Dang","female");
// addFather(userId,"Pat","Van",0);
// addMother(userId,"Ngoc","Dang",0);
// addMother(userId,"Ama","Van",1);
// displayFam(userId,0);
logIn("myvu@gmail.com","oof12345");
var holder = {};

auth.onAuthStateChanged(function(user) {
    if (user) {
        // console.log(firebase.auth().currentUser);
        console.log("Logged");
        // console.log(user);
        // console.log("Before" + Object.keys(holder).length)
        holder = read();
        console.log("This is the holder is " + holder.toString());
        // console.log("After: " + Object.keys(holder).length)
        const mother = new Person(1, holder,"Lindsey");
        holder[0].setAsMother(mother);
        console.log("This is the length of the returned " + holder.length);
        console.log(auth);
    } else {
        // console.log("Nothing");
    }
});




//console.log(tryMe());