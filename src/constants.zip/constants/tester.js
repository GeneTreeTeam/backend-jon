import { signUp } from "./auth2.js";

signUp("blah","fml123@gmail.com","oof12345");